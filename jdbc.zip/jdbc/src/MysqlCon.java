import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
class MysqlCon{
    public List<Student> readFile() {
        List<Student> list = new ArrayList<>();
        try (FileInputStream file = new FileInputStream("C:\\DOC\\std.xlsx")) {
            XSSFWorkbook workbook = new XSSFWorkbook(file);
            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> iterator = sheet.iterator();

            while (iterator.hasNext()) {
                Row currentRow = iterator.next();
                Iterator<Cell> cellIterator = currentRow.iterator();
                Student s = new Student();
                while (cellIterator.hasNext()) {
                    Cell currentCell = cellIterator.next();
                    switch (currentCell.getCellType()) {
                        case Cell.CELL_TYPE_STRING:
                            System.out.print(currentCell.getStringCellValue() + "\t");
                            s.name = currentCell.getStringCellValue();
                            break;
                        case Cell.CELL_TYPE_NUMERIC:
                            System.out.print(currentCell.getRowIndex() + "\t");
                            s.rno = currentCell.getRowIndex();
                            break;
                    }
                }
                list.add(s);
                System.out.println();
            }
            workbook.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return list;
    }
    public void writeFile() throws IOException{
        FileInputStream file = new FileInputStream("C:\\DOC\\std.xlsx");
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        FileOutputStream outputStream = new FileOutputStream("C:\\DOC\\std.xlsx");

        Sheet sheet = workbook.getSheetAt(0);

        Scanner sc = new Scanner(System.in);
        int rowNum = sheet.getLastRowNum();
        System.out.println("Number of times you want to Enter Data");
        int n = sc.nextInt();
        for(int i=0;i<n;i++) {
            System.out.println("Enter values");

            int rno = sc.nextInt();
            String Name = sc.nextLine();

            Row row = sheet.createRow(++rowNum);
            int columnCount = 0;

            Cell cell = row.createCell(columnCount);
            cell.setCellValue(rno);

            cell = row.createCell(++columnCount);
            cell.setCellValue(Name);
        }
        file.close();

        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
    }
    public static void main(String args[]){
        try{
            MysqlCon rw = new MysqlCon();
            rw.writeFile();
            // Write to a Excel file
            List<Student> list = rw.readFile();
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con=DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/student","root","smylierahul@1998");
            Statement stmt1=con.createStatement();
            for(int i=1;i<list.size();i++) {
                String name = list.get(i).name;
                int rno = list.get(i).rno;
                stmt1.executeUpdate("insert into Newstudent (rno,name)values ('"+rno+"','"+name+"')");

            }
            System.out.println("Inserted");

////            System.out.println("Inserting records into the table...");
//            String sql = "insert into Records Values (10, 'Zara', '7th')";
////            String sql = "DELETE FROM Records " +
////                    "WHERE ROLLNO = 3";
//
//            stmt1.executeUpdate(sql);


//            Statement stmt=con.createStatement();
//            ResultSet rs =stmt.executeQuery("select * from Records");
//
//            while(rs.next())
//                System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));

//            con.close();
        }catch(Exception e){ System.out.println(e);}
    }
}
