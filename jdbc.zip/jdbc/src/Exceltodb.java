
import java.io.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class Exceltodb {
    public static void readfileee() throws IOException {
        FileInputStream fis=new FileInputStream("C:\\DOC\\std.xlsx");
//creating workbook instance that refers to .xls file
        XSSFWorkbook wb=new XSSFWorkbook(fis);
//creating a Sheet object to retrieve the object
        XSSFSheet sheet=wb.getSheetAt(0);
//evaluating cell type
        FormulaEvaluator formulaEvaluator=wb.getCreationHelper().createFormulaEvaluator();
        for(Row row: sheet)     //iteration over row using for each loop
        {
            for(Cell cell: row)    //iteration over cell using for each loop
            {
                switch(formulaEvaluator.evaluateInCell(cell).getCellType())
                {
                    case Cell.CELL_TYPE_NUMERIC:   //field that represents numeric cell type
//getting the value of the cell as a number
                        System.out.print(cell.getNumericCellValue()+ " \t\t\t ");
                        break;
                    case Cell.CELL_TYPE_STRING:    //field that represents string cell type
//getting the value of the cell as a string
                        System.out.print(cell.getStringCellValue()+ " \t\t\t ");
                        break;
                }
            }
            System.out.println();
        }
    }
    public static void writeindb() throws SQLException, IOException {
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student","root","smylierahul@1998");
        Statement stmt=con.createStatement();

        //create a new table in the database 'places'
//        String sql="create table places (LOCATION_ID decimal(4,0), STREET_ADDRESS varchar(40),POSTAL_CODE varchar(12),CITY varchar(30),STATE_PROVINCE varchar(25),COUNTRY_ID varchar(2))";
//        stmt.execute(sql);

        //Excel
        FileInputStream fis=new FileInputStream("C:\\DOC\\std.xlsx");
        XSSFWorkbook workbook=new XSSFWorkbook(fis);
        XSSFSheet sheet=workbook.getSheetAt(0);

        int rows=sheet.getLastRowNum();

        for(int r=1;r<=rows;r++)
        {
            XSSFRow row=sheet.getRow(r);
            int stdid= (int) row.getCell(0).getNumericCellValue();
            String stdnm=row.getCell(1).getStringCellValue();


            String sql="insert into Newstudent values('"+stdid+"', '"+stdnm+"')";
            stmt.execute(sql);
            stmt.execute("commit");
        }


        workbook.close();
        fis.close();
        con.close();

        System.out.println("Done!!");
    }

    public static void writeFile() throws IOException{
        FileInputStream file = new FileInputStream("C:\\DOC\\std.xlsx");
        XSSFWorkbook workbook = new XSSFWorkbook(file);
        FileOutputStream outputStream = new FileOutputStream("C:\\DOC\\std.xlsx");

        Sheet sheet = workbook.getSheetAt(0);

        Scanner sc = new Scanner(System.in);
        int rowNum = sheet.getLastRowNum();
        System.out.println("Number of times you want to Enter Data");
        int n = sc.nextInt();
        for(int i=0;i<n;i++) {
            System.out.println("Enter values");

            int rno = sc.nextInt();
            String Name = sc.nextLine();

            Row row = sheet.createRow(++rowNum);
            int columnCount = 0;

            Cell cell = row.createCell(columnCount);
            cell.setCellValue(rno);

            cell = row.createCell(++columnCount);
            cell.setCellValue(Name);
        }
        file.close();

        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
    }
    public static void main(String[] args) throws SQLException, IOException {
        Exceltodb C = new Exceltodb();
//        readfileee();
//        writeFile();
//        writeindb();
//
//        Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Employees","root","smylierahul@1998");
//        Statement stmp = con.createStatement();
//        FileInputStream fis = new FileInputStream("C:\\Users\\Admin\\JAVA\\Assignments\\jdbc\\databases\\emp.xlsx");
//        XSSFWorkbook workbook = new XSSFWorkbook(fis);
//       XSSFSheet sheet= workbook.getSheet("empdata");
//
//       int rows;
//        rows = sheet.getLastRowNum();
//
//        for(int r=1;r<=rows;r++)
//        {
//            XSSFRow row=sheet.getRow(r);
//            int empId= (int) row.getCell(0).getNumericCellValue();
//            String empnm=row.getCell(1).getStringCellValue();
//
//           String sql="insert into EmpRecords values('"+empId+"', '"+empnm+"')";
//
//            stmp.execute(sql);
//            stmp.execute("commit");
//        }
//
//
//        workbook.close();
//        fis.close();
//        con.close();

        System.out.println("Done!!");
    }
}
