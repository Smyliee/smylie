public class Student {
    int rno;
    String name;

    public Student(int rno, String name) {
        this.rno = rno;
        this.name = name;
    }

    public Student() {
    }
}
